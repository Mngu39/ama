#pragma once
#include "../core/move.h"
#include "../core/chain.h"
#include <array>
#include <algorithm>
#include <stdexcept>

class PuyoEnv {
public:
    static constexpr int ACTION_COUNT = 22;
    static constexpr int MAX_TURNS = 50;

    struct Observation {
        // board[0] is the bottom row
        std::array<std::array<char, 6>, 13> board{};
        u8 row14 = 0;
        std::array<cell::Pair, 3> visible{};
        int turn = 0;
    };
    struct Result {
        Observation observation;
        int chains = 0;
        int score = 0;
        bool terminated = false;
        bool truncated = false;
    };

    Observation reset(u32 seed) {
        field_ = Field();
        queue_ = cell::create_queue(seed);
        turn_ = 0;
        done_ = false;
        return observation();
    }
    Observation observation() {
        Observation obs;
        for (int y = 0; y < 13; ++y) {
            for (int x = 0; x < 6; ++x) {
                obs.board[y][x] = cell::to_char(
                    field_.get_cell(x, y)
                );
            }
        }

        obs.row14 = field_.row14;
        for (int i = 0; i < 3; ++i) {
            obs.visible[i] = queue_.at(turn_ + i);
        }
        obs.turn = turn_;
        return obs;
    }
    std::array<bool, ACTION_COUNT> legal_actions() {
        std::array<bool, ACTION_COUNT> mask{};
        if (done_ || turn_ >= MAX_TURNS) return mask;

        auto pair = queue_.at(turn_);
        auto moves = move::generate(
            field_, pair.first == pair.second
        );

        for (int i = 0; i < moves.get_size(); ++i) {
            mask[encode_action(moves[i])] = true;
        }
        return mask;
    }
    Result step(int action_id) {
        if (done_) {
            throw std::logic_error("Episode already ended");
        }

        auto mask = legal_actions();
        if (action_id < 0 || action_id >= ACTION_COUNT
            || !mask[action_id]) {
            throw std::invalid_argument("Illegal action");
        }

        auto placement = decode_action(action_id);
        field_.drop_pair(
            placement.x, placement.r, queue_.at(turn_)
        );
        auto popped = field_.pop();
        auto outcome = chain::get_score(popped);
        ++turn_;

        bool truncated = (turn_ >= MAX_TURNS);
        bool terminated = false;

        if (!truncated) {
            auto next_mask = legal_actions();
            terminated = std::none_of(
                next_mask.begin(), next_mask.end(),
                [](bool legal) { return legal; }
            );
        }
        done_ = terminated || truncated;
        return {
            observation(),
            outcome.count,
            outcome.score,
            terminated,
            truncated
        };
    }

    // Simulate one legal action without changing the real environment.
    // The copy owns a separate field, queue and turn counter.
    Result preview(int action_id) const {
        PuyoEnv simulated = *this;
        return simulated.step(action_id);
    }

    bool done() const { return done_; }

private:
    Field field_;
    cell::Queue queue_;
    int turn_ = 0;
    bool done_ = false;
    static int encode_action(move::Placement p) {
        switch (p.r) {
        case direction::Type::UP:    return p.x;
        case direction::Type::RIGHT: return 6 + p.x;
        case direction::Type::DOWN:  return 11 + p.x;
        case direction::Type::LEFT:  return 16 + p.x;
        }
        throw std::invalid_argument("Invalid rotation");
    }
    static move::Placement decode_action(int id) {
        if (id < 6)
            return {static_cast<i8>(id), direction::Type::UP};
        if (id < 11)
            return {static_cast<i8>(id - 6), direction::Type::RIGHT};
        if (id < 17)
            return {static_cast<i8>(id - 11), direction::Type::DOWN};
        return {static_cast<i8>(id - 16), direction::Type::LEFT};
    }
};
